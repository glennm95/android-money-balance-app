package edu.uic.cs478.gmasca2.project5app2;

import android.app.Activity;
import android.os.Bundle;

public class App2MainActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_app2_main);
    }
}
